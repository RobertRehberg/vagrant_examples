#ifndef PSYCH_TO_RUBY_H
#define PSYCH_TO_RUBY_H

#include <psych.h>

void Init_psych_to_ruby(void);

#endif
