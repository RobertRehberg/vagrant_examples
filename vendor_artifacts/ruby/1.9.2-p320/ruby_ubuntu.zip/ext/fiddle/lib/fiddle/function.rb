module Fiddle
  class Function
    attr_reader :abi
  end
end
