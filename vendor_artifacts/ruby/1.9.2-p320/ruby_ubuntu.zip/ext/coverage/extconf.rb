require 'mkmf'
create_makefile('coverage')
